group = "org.limine.snapper"
version = "1.31.0"

plugins {
    application
    id("org.graalvm.buildtools.native") version "1.1.3"
}

application {
    mainClass.set("org.limine.snapper.Main")
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("tools.jackson.core:jackson-databind:3.2.0")
}

graalvmNative {
    toolchainDetection.set(true)
    binaries {
        named("main") {
            fallback.set(false)
            verbose.set(false)

            buildArgs.add("--gc=serial")
            buildArgs.add("-march=compatibility")
            buildArgs.add("-R:MaxHeapSize=128m")
            buildArgs.add("-Os") //Reduce binary size

            buildArgs.add("-H:+UnlockExperimentalVMOptions")
            buildArgs.add("-H:ReflectionConfigurationFiles=${file("src/main/resources/reflect-config.json").absolutePath}")

            imageName.set("limine-snapper-sync")
            mainClass.set(application.mainClass)
        }
    }
    tasks.test {
        enabled = false
    }
}