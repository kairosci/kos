package org.limine.snapper.processes;

import org.limine.snapper.formats.json1.SnapperEntry;
import org.limine.snapper.formats.snapper.SnapperProperty;
import org.limine.snapper.objects.Config;
import org.limine.snapper.objects.Output;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class SnapperReader {

    private final LinkedHashMap<String, SnapperEntry> snapperEntries;
    private final Integer addedID;
    private SnapperEntry addedEntry;

    public SnapperReader(String addedID) {
        this.addedID = parseId(addedID);
        this.snapperEntries = new LinkedHashMap<>();
        this.process();
        if (addedEntry == null && !snapperEntries.isEmpty()) {
            addedEntry = snapperEntries.lastEntry().getValue();
        }
    }

    private Integer parseId(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Integer.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void process() {
        readList();
        // If no snapper entries are found, verify /.snapshots setup.
        // Important: This prevents accidental deletion of all snapshot entries due to user error.
        if (!validateSnapshots()) {
            return;
        }
        if (Config.USE_OPENSUSE_LAYOUT) {
            cleanupOpenSuseWritableCopyEntry();
        }
    }

    private void readList() {
        snapperEntries.clear();
        Output output = Utility.getCommandOutput(Config.SNAPPER_LIST_CMDLINE, true, null);
        if (!output.isSuccess()) {
            return;
        }
        for (String line : output.text()) {
            // Check if snapshot ID is number.
            if (!line.isEmpty() && Character.isDigit(line.charAt(0))) {
                SnapperEntry entry = createSnapperEntry(line);
                if (entry == null) {
                    continue;
                }
                snapperEntries.put(entry.timeId(), entry);
                if (addedID != null && addedID.equals(entry.snapshotID())) {
                    addedEntry = entry;
                }
            }
        }
    }

    private SnapperEntry createSnapperEntry(String line) {
        String[] columns = line.split(",");
        if (columns.length >= 2) {
            // Trim each part to remove any leading/trailing whitespace
            int snapshotID = Integer.parseInt(columns[0].trim());
            String utcTime = columns[1].trim();
            if (snapshotID == 0) {
                return null;

            } else if (Utility.isTimeFormatNotValid(utcTime)) {
                Utility.exitWithError("Stopping the sync:", "because the Snapper time format has changed: " + utcTime);
                return null;
            }

            String description = "";
            if (columns.length >= 4) {
                description = columns[3];
            }
            String type = "";
            if (columns.length >= 3) {
                type = columns[2];
            }
            Map<String, String> properties = new HashMap<>();
            properties.put(SnapperProperty.DESCRIPTION.replace, description);
            properties.put(SnapperProperty.TYPE.replace, type);
            String localTime = Utility.convertUTCtoLocal(utcTime);
            return new SnapperEntry(snapshotID, utcTime, localTime, properties);

        } else {
            String errMessage = "Mismatch Snapper format output!";
            Utility.exitWithError(errMessage);
            return null;
        }
    }

    private int countNumericFoldersWithSnapshot() {
        Path path = Paths.get("/.snapshots");
        int count = 0;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(path, Files::isDirectory)) {
            for (Path entry : stream) {
                String name = entry.getFileName().toString();
                if (name.isEmpty()) continue;
                boolean numeric = name.chars().allMatch(Character::isDigit);
                if (!numeric) continue;
                if (Files.isDirectory(entry.resolve("snapshot"))) {
                    count++;
                }
            }
        } catch (IOException ignored) {
        }
        return count;
    }

    private boolean validateSnapshots() {
        if (!snapperEntries.isEmpty()) {
            return true;
        }
        if (!Utility.isDirectoryPresent("/.snapshots")) {
            Utility.exitWithError("\"/.snapshots\" directory is missing.");
            return false;
        }
        if (!Utility.runCommand("btrfs subvolume show /.snapshots", false, false, false)) {
            Utility.exitWithError("\"/.snapshots\" is not a Btrfs subvolume.");
            return false;
        }
        if (countNumericFoldersWithSnapshot() > 0) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ignored) {
            }
            readList();
            if (snapperEntries.isEmpty() && countNumericFoldersWithSnapshot() > 0) {
                Utility.exitWithError("Snapper returned an empty snapshot list, but \"/.snapshots\" is not empty. Snapper may be slow or inconsistent.");
            }
        }
        Utility.warnMessage("No snapshots available.");
        return false;
    }

    private void cleanupOpenSuseWritableCopyEntry() {
        SnapperEntry entry = snapperEntries.lastEntry().getValue();
        if (entry == null) {
            return;
        }
        // If the last snapper ID contains the description "writable copy of #<ID>", then it should be ignored.
        String description = entry.properties().get(SnapperProperty.DESCRIPTION.replace);
        if (description != null && description.startsWith("writable copy of #")) {
            snapperEntries.remove(snapperEntries.lastEntry().getKey());
            if (Objects.equals(addedEntry, entry)) {
                addedEntry = snapperEntries.lastEntry().getValue();
            }
        }
    }

    public HashMap<String, SnapperEntry> getEntries() {
        return snapperEntries;
    }

    public SnapperEntry lastEntry() {
        if (snapperEntries.isEmpty()) {
            return null;
        }
        return addedEntry;
    }
}
