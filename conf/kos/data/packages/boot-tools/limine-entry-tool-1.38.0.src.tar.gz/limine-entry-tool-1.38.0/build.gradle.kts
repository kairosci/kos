group = "org.limine.entry.tool"
version = "1.38.0"

plugins {
    application
    id("org.graalvm.buildtools.native") version "1.1.11"
}

application {
    mainClass.set("org.limine.entry.tool.Main")
}

repositories {
    mavenCentral()
}

graalvmNative {
    toolchainDetection.set(true)
    binaries {
        named("main") {
            verbose.set(false)

            buildArgs.add("--gc=serial")
            buildArgs.add("-march=compatibility")
            buildArgs.add("-R:MaxHeapSize=32m")
            buildArgs.add("-Os") //Reduce binary size

            imageName.set("limine-entry-tool")
            mainClass.set(application.mainClass)
        }
    }
    tasks.test {
        enabled = false
    }
}