package org.limine.entry.tool.processes;

import org.limine.entry.tool.formats.limine8.Limine;
import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.ConsoleColor;
import org.limine.entry.tool.objects.EfiBootEntry;
import org.limine.entry.tool.objects.Output;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.limine.entry.tool.processes.Utility.infoMessage;


public class EfiScanner {

    public static EfiBootEntry showEfiEntriesAndSelect() {
        List<EfiBootEntry> entries = getEfiBootEntries();
        if (entries.isEmpty()) {
            System.out.println(ConsoleColor.RED + "No EFI boot entries found." + ConsoleColor.RESET);
            return null;
        }
        infoMessage("Available EFI Boot Entries:");
        String upOrDown = Config.ENABLE_UNICODE ? "↑/↓" : "Up/Down";
        printEntries(entries);
        System.out.printf("\n [%s] select | type [1-%d] | [c] cancel%n", upOrDown, entries.size());
        System.out.println();

        List<String> ids = new ArrayList<>(entries.size());
        for (int i = 0; i < entries.size(); i++) {
            ids.add(String.valueOf(i + 1));
        }

        String input = TerminalReader.readLine("Choice: ", ids, null);
        if (input.equalsIgnoreCase("c")) {
            System.exit(0);
            return null; // canceled
        }
        try {
            int selectedIndex = Integer.parseInt(input);
            if (selectedIndex < 1 || selectedIndex > entries.size()) {
                System.out.println(ConsoleColor.RED + "Invalid selection." + ConsoleColor.RESET);
                return null;
            }
            EfiBootEntry entry = entries.get(selectedIndex - 1);
            String customName = promptEntryName(entry.name());
            return new EfiBootEntry(customName, entry.comment(), entry.gptUuid(), entry.efiPath());
        } catch (NumberFormatException e) {
            System.out.println(ConsoleColor.RED + "Invalid selection." + ConsoleColor.RESET);
            return null;
        }
    }

    public static List<EfiBootEntry> getEfiBootEntries() {
        List<EfiBootEntry> efiEntries = new ArrayList<>();
        Output output = Utility.getCommandOutput("efibootmgr", true, true);
        if (!output.isSuccess()) {
            return efiEntries;
        }
        // Regex pattern to match boot entries and ignore case for .efi extension
        Pattern regex = Pattern.compile("\\s+(.+?)\\s+HD\\(\\d+,GPT,([0-9a-fA-F-]+),[^)]+\\)(/\\S+(?i).efi)");
        for (String line : output.text()) {
            Matcher matcher = regex.matcher(line);
            if (matcher.find()) {
                String name = matcher.group(1).trim();
                String gptUuid = matcher.group(2).trim();
                String efiPath = matcher.group(3).trim();

                // Clean the EFI path by removing non-printable or invalid characters
                String validEfiPath = efiPath.replaceAll("[^\\x20-\\x7E]", "")
                        .replace("\\", "/") // Convert Windows-style backslashes to Unix-style slashes
                        .replace("//", "/");

                // Only add valid entries
                if (!validEfiPath.isEmpty()) {
                    efiEntries.add(new EfiBootEntry(name, name, gptUuid, validEfiPath));
                }
            }
        }
        return efiEntries;
    }

    public static void printEntries(List<EfiBootEntry> entries) {
        int indexWidth = Math.max(2, String.valueOf(entries.size()).length());
        int nameWidth = "Name".length();
        int uuidWidth = "GPT UUID".length();
        int pathWidth = "EFI Path".length();
        for (EfiBootEntry e : entries) {
            nameWidth = Math.max(nameWidth, e.name().length());
            uuidWidth = Math.max(uuidWidth, e.gptUuid().length());
            pathWidth = Math.max(pathWidth, e.efiPath().length());
        }
        String sep = Config.ENABLE_UNICODE ? " │ " : " | ";
        String cross = Config.ENABLE_UNICODE ? "─┼─" : "-|-";
        char line = Config.ENABLE_UNICODE ? '─' : '-';
        StringBuilder sb = new StringBuilder();
        // Header
        sb.append(pad("#", indexWidth)).append(sep)
                .append(pad("Name", nameWidth)).append(sep)
                .append(pad("GPT UUID", uuidWidth)).append(sep)
                .append(pad("EFI Path", pathWidth)).append("\n");
        // Separator
        sb.append(repeat(line, indexWidth)).append(cross)
                .append(repeat(line, nameWidth)).append(cross)
                .append(repeat(line, uuidWidth)).append(cross)
                .append(repeat(line, pathWidth)).append("\n");
        // Rows
        for (int i = 0; i < entries.size(); i++) {
            EfiBootEntry e = entries.get(i);
            sb.append(pad(String.valueOf(i + 1), indexWidth)).append(sep)
                    .append(pad(e.name(), nameWidth)).append(sep)
                    .append(pad(e.gptUuid(), uuidWidth)).append(sep)
                    .append(pad(e.efiPath(), pathWidth)).append("\n");
        }
        System.out.print(sb);
    }

    private static String pad(String str, int width) {
        if (str.length() >= width) return str;
        return str + " ".repeat(width - str.length());
    }

    private static String repeat(char c, int n) {
        return String.valueOf(c).repeat(Math.max(0, n));
    }

    private static String promptEntryName(String name) {
        String customName = TerminalReader.readLine("New entry name: ", List.of(name), 0).trim();
        if ("c".equals(customName) || "cancel".equals(customName)) {
            System.exit(0);
        }
        if (customName.startsWith(Limine.ENTRY_KEY.toString()) || customName.startsWith(Limine.EXPAND.toString())) {
            customName = name;
        }
        return customName.isBlank() ? name : customName;
    }
}