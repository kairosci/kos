package org.limine.entry.tool.objects;

public record EfiBootEntry(String name, String comment, String gptUuid, String efiPath) {
}
