package org.limine.entry.tool.objects;

import org.limine.entry.tool.formats.limine8.Limine;
import org.limine.entry.tool.processes.MacroReplacer;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TreeNode implements Comparable<TreeNode> {

    private final List<String> configLines;
    private final LinkedList<TreeNode> nodes;
    private final int depth;
    private final String parentNodeName;
    public String name, cleanName;
    private EntryOptions options;
    private boolean enableLineBreak;

    public TreeNode(String name, int depth, String parentNodeName) {
        this.name = name;
        this.cleanName = MacroReplacer.replaceMacros(Limine.cleanName(name));
        this.configLines = new ArrayList<>();
        this.nodes = new LinkedList<>();
        this.depth = depth;
        this.parentNodeName = parentNodeName;
        this.enableLineBreak = false;
        this.options = null;
    }

    public void addConfigLine(String line) {
        this.configLines.add(line);
    }

    public void addNode(TreeNode node) {
        this.nodes.add(node);
    }

    public void addNode(int index, TreeNode node) {
        this.nodes.add(index, node);
    }

    public TreeNode findOsNode(String machineID, String osName, int selectedDepth) {
        TreeNode node = findNodeByMachineID(machineID, selectedDepth);
        if (node == null) {
            return findNodeByCleanName(osName, machineID, selectedDepth);
        } else {
            return node;
        }
    }

    public TreeNode findNodeByCleanName(String nodeCleanName, String machineID, int selectedDepth) {
        if (nodeCleanName == null || nodeCleanName.isEmpty()) return null;
        // Check for match at target depth
        if (selectedDepth <= 0) {
            if (!nodeCleanName.equals(this.cleanName)) return null;
            // Match if machineID is null/empty or matches current machine
            boolean machineIDMatches = this.options == null
                    || this.options.getMachineID() == null
                    || this.options.getMachineID().isEmpty()
                    || this.options.getMachineID().equals(machineID);
            return machineIDMatches ? this : null;
        }
        // Search children with reduced depth
        int remainingDepth = selectedDepth - 1;
        for (TreeNode node : nodes) {
            TreeNode result = node.findNodeByCleanName(nodeCleanName, machineID, remainingDepth);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    public int findPositionByLowerPriority(int priority) {
        int position = 0; // 0 is the highest priority.
        for (TreeNode node : nodes) {
            if (priority > node.getOrCreateOptions().getPriority()) {
                return position;
            }
            position++;
        }
        return position; // The lowest priority.
    }

    public TreeNode findNodeByMachineID(String machineID, int selectedDepth) {
        if (0 >= selectedDepth) {
            if (machineID.equals(this.getOrCreateOptions().getMachineID())) {
                return this;
            }
            return null;
        }
        selectedDepth--;
        for (TreeNode node : nodes) {
            TreeNode result = node.findNodeByMachineID(machineID, selectedDepth);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    public boolean searchNodeByName(String nodeName, int selectedDepth) {
        if (0 >= selectedDepth) {
            return this.name.trim().equals(nodeName);
        }
        selectedDepth--;
        for (TreeNode node : nodes) {
            if (node.searchNodeByName(nodeName, selectedDepth)) {
                return true;
            }
        }
        return false;
    }

    public void printTree(String prefix, boolean isLast, int limitDepth) {
        // Skip root (depth == 0), just recurse into children
        if (depth == 0) {
            for (TreeNode node : nodes) {
                node.printTree("", true, limitDepth);
            }
            return;
        }

        // Print current node
        if (depth == 1) {
            // Top-level nodes have no branch prefix
            System.out.println(cleanName);
        } else {
            String branch = isLast ? "└─ " : "├─ ";
            System.out.println(prefix + branch + cleanName);
        }

        // Stop recursion if depth limit reached or no children
        if (depth >= limitDepth || nodes.isEmpty()) {
            return;
        }

        // Top-level nodes have no indent prefix, deeper nodes indent based on isLast
        String childPrefix = (depth == 1) ? "" : prefix + (isLast ? "   " : "│  ");
        int lastIndex = nodes.size() - 1;
        for (int i = 0; i <= lastIndex; i++) {
            nodes.get(i).printTree(childPrefix, i == lastIndex, limitDepth);
        }
    }

    @Override
    public String toString() {
        return "TreeNode{" + "name='" + name + '\'' + ", configBlock=" + configLines + ", depth=" + depth + ", parentNodeName='" + parentNodeName + '\'' + '}';
    }

    public List<String> getConfigLines() {
        return configLines;
    }

    public LinkedList<TreeNode> getNodes() {
        return nodes;
    }

    public boolean isEnableLineBreak() {
        return enableLineBreak;
    }

    public void setEnableLineBreak(boolean enableLineBreak) {
        this.enableLineBreak = enableLineBreak;
    }

    public String getName() {
        return name;
    }

    public String getCleanName() {
        return cleanName;
    }

    public EntryOptions getOrCreateOptions() {
        if (this.options == null) {
            this.options = new EntryOptions();
            for (String line : this.configLines) {
                if (line.trim().startsWith(Limine.COMMENT.toString())) {
                    this.options.parseComment(MacroReplacer.replaceMacros(line));
                }
            }
        }
        return options;
    }

    public void setOptions(EntryOptions options) {
        this.options = options;
    }

    @Override
    public int compareTo(TreeNode other) {
        return this.cleanName.compareTo(other.cleanName);
    }

    public void clear() {
        name = "";
        cleanName = "";
        options = null;
        configLines.clear();
        nodes.clear();
        enableLineBreak = false;
    }
}
