package org.limine.entry.tool.objects;

import org.limine.entry.tool.processes.ConfigReader;

import java.util.LinkedHashSet;
import java.util.Map;

public class BootOptions {

    public static final Map<String, String> KERNEL_CMDLINE_MAP = new ConfigReader().readBootOptions();

    public static String getKernelCmdline(String key) {
        String cmdline = KERNEL_CMDLINE_MAP.get(key);

        if ((cmdline == null || cmdline.isBlank()) && key.contains("fallback")) {
            cmdline = KERNEL_CMDLINE_MAP.get("fallback");
        }

        if (cmdline == null || cmdline.isBlank()) {
            cmdline = KERNEL_CMDLINE_MAP.get("default");
        }
        return cmdline;
    }

    /**
     * Extracts all "initrd=" parameters from a kernel cmdline
     * and returns a pair: (cmdline without initrd, List of all initrds).
     */
    public static KernelParams cleanKernelParameters(String kernelCmdline, boolean extractInitrds) {
        String[] parameters = kernelCmdline.split(" ");
        LinkedHashSet<String> initrds = new LinkedHashSet<>();
        LinkedHashSet<String> cleaned = new LinkedHashSet<>(parameters.length);
        for (String parameter : parameters) {
            if (extractInitrds && parameter.startsWith("initrd=")) {
                String path = parameter.substring("initrd=".length());
                if (!path.isBlank()) {
                    initrds.add(path);
                }
            } else {
                cleaned.add(parameter);
            }
        }
        return new KernelParams(String.join(" ", cleaned), initrds);
    }

    public record KernelParams(String cmdline, LinkedHashSet<String> initrds) {
    }

}
